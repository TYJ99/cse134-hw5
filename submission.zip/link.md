part1: https://lively-panda-dcef0e.netlify.app/methodtest.html

part2: https://lively-panda-dcef0e.netlify.app/webcomponent.html

github: https://github.com/TYJ99/cse134-hw5