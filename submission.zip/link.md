https://regal-caramel-42684f.netlify.app/nativedialogs.html

https://regal-caramel-42684f.netlify.app/customdialogs.html

https://regal-caramel-42684f.netlify.app/crud.html

https://regal-caramel-42684f.netlify.app/styledcrud.html

https://github.com/TYJ99/cse134-hw4